from django.apps import AppConfig


class ThemsConfig(AppConfig):
    name = 'thems'
